library(dplyr)
library(tidyverse)
library(readxl)
library(stringr)
library(MASS)


#Plot 1
planting1 = read_excel("others1.xlsx")
planting1 = tibble(planting1)

months <- strsplit(planting1$Date, ' ') %>% lapply('[[', 1)
day <- strsplit(planting1$Date, ' ') %>% lapply('[[', 2)
year <- strsplit(planting1$Date, ' ') %>% lapply('[[', 3)

year <- str_remove(year, "'")

day <- unlist(day)
day <- str_remove(day, "th")
day <- str_remove(day, "rd")
day <- str_remove(day, "st")

months <- unlist(months)
months <- replace(months, c(1, 2, 3, 4), "11")
months <- replace(months, c(5, 6, 7, 8), "12")
months <- replace(months, c(9, 10, 11), "1")
months <- replace(months, c(12, 13), "2")
months <- replace(months, c(14, 15, 16), "3")

planting1$Month <- months
planting1$Day <- day
planting1$Year <- year

planting1$Total_Date <- paste(year, months, day, sep=".")
labeling <- paste(months, day, sep=".")

planting1 = planting1 %>% rename("Genesis"= "ND Genesis")
planting1 = planting1 %>% rename("ndsu"= "ndsu-2nd32529")

colors<- c("Conlon"="red", "Robust"="orange", "Rasmusson"="yellow", "ND Genesis"="green", "Opera"="blue", "Copeland"="purple", "Ndsu-2nd32529"="white", "Genie"="pink", "Odyssey"="brown", "Pinnacle"="tan")

ggplot(planting1, aes(x=Total_Date))+
  geom_line(aes(y = Conlon, group=1, color="Conlon")) + 
  geom_line(aes(y=Robust, group=1, color="Robust"))+
  geom_line(aes(y=Rasmusson, group=1, color="Rasmusson"))+
  geom_line(aes(y=Genesis, group=1, color="ND Genesis"))+
  geom_line(aes(y=opera, group=1, color="Opera"))+
  geom_line(aes(y=copeland, group=1, color="Copeland"))+
  geom_line(aes(y=ndsu, group=1, color="Ndsu-2nd32529"))+
  geom_line(aes(y=genie, group=1, color="Genie"))+
  geom_line(aes(y=odyssey, group=1, color="Odyssey"))+
  geom_line(aes(y=pinnacle, group=1, color="Pinnacle"))+
  scale_x_discrete(labels=labeling) + 
  ggtitle("First Planting Date w/ ten varieties (Height)") +
  xlab("Month-Day (2021-2022)") +
  ylab("Average Height (cm)")+
  theme_dark()+
  theme(axis.text=element_text(size=8))+
  scale_color_manual(values=colors)+
  labs(color="Color")

planting1 = read_excel("planting1feekes.xlsx")
planting1 = tibble(planting1)

months <- strsplit(planting1$Date, ' ') %>% lapply('[[', 1)
day <- strsplit(planting1$Date, ' ') %>% lapply('[[', 2)
year <- strsplit(planting1$Date, ' ') %>% lapply('[[', 3)

year <- str_remove(year, "'")

day <- unlist(day)
day <- str_remove(day, "th")
day <- str_remove(day, "rd")
day <- str_remove(day, "st")

months <- unlist(months)
months <- replace(months, c(1, 2, 3, 4), "11")
months <- replace(months, c(5, 6, 7, 8), "12")
months <- replace(months, c(9, 10, 11), "1")
months <- replace(months, c(12, 13), "2")
months <- replace(months, c(14, 15, 16), "3")

planting1$Month <- months
planting1$Day <- day
planting1$Year <- year

planting1$Total_Date <- paste(year, months, day, sep=".")
labeling <- paste(months, day, sep=".")

planting1 = planting1 %>% rename("Genesis"= "ND Genesis")
planting1 = planting1 %>% rename("ndsu"= "ndsu-2nd32529")

colors<- c("Conlon"="red", "Robust"="orange", "Rasmusson"="yellow", "ND Genesis"="green", "Opera"="blue", "Copeland"="purple", "Ndsu-2nd32529"="white", "Genie"="pink", "Odyssey"="brown", "Pinnacle"="tan")

ggplot(planting1, aes(x=Total_Date))+
  geom_line(aes(y = Conlon, group=1, color="Conlon")) + 
  geom_line(aes(y=Robust, group=1, color="Robust"))+
  geom_line(aes(y=Rasmusson, group=1, color="Rasmusson"))+
  geom_line(aes(y=Genesis, group=1, color="ND Genesis"))+
  geom_line(aes(y=opera, group=1, color="Opera"))+
  geom_line(aes(y=copeland, group=1, color="Copeland"))+
  geom_line(aes(y=ndsu, group=1, color="Ndsu-2nd32529"))+
  geom_line(aes(y=genie, group=1, color="Genie"))+
  geom_line(aes(y=odyssey, group=1, color="Odyssey"))+
  geom_line(aes(y=pinnacle, group=1, color="Pinnacle"))+
  scale_x_discrete(labels=labeling) + 
  ggtitle("First Planting Date w/ ten varieties (Feekes Scale)") +
  xlab("Month-Day (2021-2022)") +
  ylab("Average Feekes Scale Rating")+
  theme_dark()+
  theme(axis.text=element_text(size=8))+
  scale_color_manual(values=colors)+
  labs(color="Color")

#Plot 2
planting2 = read_excel("planting2.xlsx")
planting2 = tibble(planting2)

months <- strsplit(planting2$Date, ' ') %>% lapply('[[', 1)
day <- strsplit(planting2$Date, ' ') %>% lapply('[[', 2)
year <- strsplit(planting2$Date, ' ') %>% lapply('[[', 3)

year <- str_remove(year, "'")

day <- unlist(day)
day <- str_remove(day, "th")
day <- str_remove(day, "rd")
day <- str_remove(day, "st")

months <- unlist(months)
months <- replace(months, c(1, 2), "11")
months <- replace(months, c(3, 4, 5, 6), "12")
months <- replace(months, c(7, 8, 9), "1")
months <- replace(months, c(10, 11), "2")
months <- replace(months, c(12, 13, 14), "3")

planting2$Month <- months
planting2$Day <- day
planting2$Year <- year

planting2$Total_Date <- paste(year, months, day, sep=".")
labeling <- paste(months, day, sep=".")

planting2 = planting2 %>% rename("genesis"= "nd genesis")
planting2 = planting2 %>% rename("ndsu"= "ndsu-2nd32529")

colors<- c("Conlon"="red", "Robust"="orange", "Rasmusson"="yellow", "ND Genesis"="green", "Opera"="blue", "Copeland"="purple", "Ndsu-2nd32529"="white", "Genie"="pink", "Odyssey"="brown", "Pinnacle"="tan")

ggplot(planting2, aes(x=Total_Date))+
  geom_line(aes(y = conlon, group=1, color="Conlon")) + 
  geom_line(aes(y=robust, group=1, color="Robust"))+
  geom_line(aes(y=rasmusson, group=1, color="Rasmusson"))+
  geom_line(aes(y=genesis, group=1, color="ND Genesis"))+
  geom_line(aes(y=opera, group=1, color="Opera"))+
  geom_line(aes(y=copeland, group=1, color="Copeland"))+
  geom_line(aes(y=ndsu, group=1, color="Ndsu-2nd32529"))+
  geom_line(aes(y=genie, group=1, color="Genie"))+
  geom_line(aes(y=odyssey, group=1, color="Odyssey"))+
  geom_line(aes(y=pinnacle, group=1, color="Pinnacle"))+
  scale_x_discrete(labels=labeling) + 
  ggtitle("Second Planting Date w/ ten varieties (Height)") +
  xlab("Month-Day (2021-2022)") +
  ylab("Average Height (cm)")+
  theme_dark()+
  theme(axis.text=element_text(size=8))+
  scale_color_manual(values=colors)+
  labs(color="Color")

planting2 = read_excel("planting2feekes.xlsx")
planting2 = tibble(planting2)

months <- strsplit(planting2$Date, ' ') %>% lapply('[[', 1)
day <- strsplit(planting2$Date, ' ') %>% lapply('[[', 2)
year <- strsplit(planting2$Date, ' ') %>% lapply('[[', 3)

year <- str_remove(year, "'")

day <- unlist(day)
day <- str_remove(day, "th")
day <- str_remove(day, "rd")
day <- str_remove(day, "st")

months <- unlist(months)
months <- replace(months, c(1, 2), "11")
months <- replace(months, c(3, 4, 5, 6), "12")
months <- replace(months, c(7, 8, 9), "1")
months <- replace(months, c(10, 11), "2")
months <- replace(months, c(12, 13, 14), "3")

planting2$Month <- months
planting2$Day <- day
planting2$Year <- year

planting2$Total_Date <- paste(year, months, day, sep=".")
labeling <- paste(months, day, sep=".")

planting2 = planting2 %>% rename("genesis"= "nd genesis")
planting2 = planting2 %>% rename("ndsu"= "ndsu-2nd32529")

colors<- c("Conlon"="red", "Robust"="orange", "Rasmusson"="yellow", "ND Genesis"="green", "Opera"="blue", "Copeland"="purple", "Ndsu-2nd32529"="white", "Genie"="pink", "Odyssey"="brown", "Pinnacle"="tan")

ggplot(planting2, aes(x=Total_Date))+
  geom_line(aes(y = conlon, group=1, color="Conlon")) + 
  geom_line(aes(y=robust, group=1, color="Robust"))+
  geom_line(aes(y=rasmusson, group=1, color="Rasmusson"))+
  geom_line(aes(y=genesis, group=1, color="ND Genesis"))+
  geom_line(aes(y=opera, group=1, color="Opera"))+
  geom_line(aes(y=copeland, group=1, color="Copeland"))+
  geom_line(aes(y=ndsu, group=1, color="Ndsu-2nd32529"))+
  geom_line(aes(y=genie, group=1, color="Genie"))+
  geom_line(aes(y=odyssey, group=1, color="Odyssey"))+
  geom_line(aes(y=pinnacle, group=1, color="Pinnacle"))+
  scale_x_discrete(labels=labeling) + 
  ggtitle("Second Planting Date w/ ten varieties (Feekes Scale)") +
  xlab("Month-Day (2021-2022)") +
  ylab("Average Height (cm)")+
  theme_dark()+
  theme(axis.text=element_text(size=8))+
  scale_color_manual(values=colors)+
  labs(color="Color")

#Plot 3
planting3 = read_excel("planting3.xlsx")
planting3 = tibble(planting3)

months <- strsplit(planting3$Date, ' ') %>% lapply('[[', 1)
day <- strsplit(planting3$Date, ' ') %>% lapply('[[', 2)
year <- strsplit(planting3$Date, ' ') %>% lapply('[[', 3)

year <- str_remove(year, "'")

day <- unlist(day)
day <- str_remove(day, "th")
day <- str_remove(day, "rd")
day <- str_remove(day, "st")

months <- unlist(months)
months <- replace(months, c(1, 2, 3, 4), "12")
months <- replace(months, c(5, 6, 7), "1")
months <- replace(months, c(8, 9), "2")
months <- replace(months, c(10, 11, 12), "3")

planting3$Month <- months
planting3$Day <- day
planting3$Year <- year

planting3$Total_Date <- paste(year, months, day, sep=".")
labeling <- paste(months, day, sep=".")

planting3 = planting3 %>% rename("genesis"= "nd genesis")
planting3 = planting3 %>% rename("ndsu"= "ndsu-2nd32529")

colors<- c("Conlon"="red", "Robust"="orange", "Rasmusson"="yellow", "ND Genesis"="green", "Opera"="blue", "Copeland"="purple", "Ndsu-2nd32529"="white", "Genie"="pink", "Odyssey"="brown", "Pinnacle"="tan")

ggplot(planting3, aes(x=Total_Date))+
  geom_line(aes(y = conlon, group=1, color="Conlon")) + 
  geom_line(aes(y=robust, group=1, color="Robust"))+
  geom_line(aes(y=rasmusson, group=1, color="Rasmusson"))+
  geom_line(aes(y=genesis, group=1, color="ND Genesis"))+
  geom_line(aes(y=opera, group=1, color="Opera"))+
  geom_line(aes(y=copeland, group=1, color="Copeland"))+
  geom_line(aes(y=ndsu, group=1, color="Ndsu-2nd32529"))+
  geom_line(aes(y=genie, group=1, color="Genie"))+
  geom_line(aes(y=odyssey, group=1, color="Odyssey"))+
  geom_line(aes(y=pinnacle, group=1, color="Pinnacle"))+
  scale_x_discrete(labels=labeling) + 
  ggtitle("Third Planting Date w/ ten varieties (Height)") +
  xlab("Month-Day (2021-2022)") +
  ylab("Average Height (cm)")+
  theme_dark()+
  theme(axis.text=element_text(size=8))+
  scale_color_manual(values=colors)+
  labs(color="Color")

planting3 = read_excel("planting3feekes.xlsx")
planting3 = tibble(planting3)

months <- strsplit(planting3$Date, ' ') %>% lapply('[[', 1)
day <- strsplit(planting3$Date, ' ') %>% lapply('[[', 2)
year <- strsplit(planting3$Date, ' ') %>% lapply('[[', 3)

year <- str_remove(year, "'")

day <- unlist(day)
day <- str_remove(day, "th")
day <- str_remove(day, "rd")
day <- str_remove(day, "st")

months <- unlist(months)
months <- replace(months, c(1, 2, 3, 4), "12")
months <- replace(months, c(5, 6, 7), "1")
months <- replace(months, c(8, 9), "2")
months <- replace(months, c(10, 11, 12), "3")

planting3$Month <- months
planting3$Day <- day
planting3$Year <- year

planting3$Total_Date <- paste(year, months, day, sep=".")
labeling <- paste(months, day, sep=".")

planting3 = planting3 %>% rename("genesis"= "nd genesis")
planting3 = planting3 %>% rename("ndsu"= "ndsu-2nd32529")

colors<- c("Conlon"="red", "Robust"="orange", "Rasmusson"="yellow", "ND Genesis"="green", "Opera"="blue", "Copeland"="purple", "Ndsu-2nd32529"="white", "Genie"="pink", "Odyssey"="brown", "Pinnacle"="tan")

ggplot(planting3, aes(x=Total_Date))+
  geom_line(aes(y = conlon, group=1, color="Conlon")) + 
  geom_line(aes(y=robust, group=1, color="Robust"))+
  geom_line(aes(y=rasmusson, group=1, color="Rasmusson"))+
  geom_line(aes(y=genesis, group=1, color="ND Genesis"))+
  geom_line(aes(y=opera, group=1, color="Opera"))+
  geom_line(aes(y=copeland, group=1, color="Copeland"))+
  geom_line(aes(y=ndsu, group=1, color="Ndsu-2nd32529"))+
  geom_line(aes(y=genie, group=1, color="Genie"))+
  geom_line(aes(y=odyssey, group=1, color="Odyssey"))+
  geom_line(aes(y=pinnacle, group=1, color="Pinnacle"))+
  scale_x_discrete(labels=labeling) + 
  ggtitle("Third Planting Date w/ ten varieties (Feekes Scale)") +
  xlab("Month-Day (2021-2022)") +
  ylab("Average Feekes Scale Rating")+
  theme_dark()+
  theme(axis.text=element_text(size=8))+
  scale_color_manual(values=colors)+
  labs(color="Color")

#Plot 4
planting4 = read_excel("planting4.xlsx")
planting4 = tibble(planting4)

months <- strsplit(planting4$Date, ' ') %>% lapply('[[', 1)
day <- strsplit(planting4$Date, ' ') %>% lapply('[[', 2)
year <- strsplit(planting4$Date, ' ') %>% lapply('[[', 3)

year <- str_remove(year, "'")

day <- unlist(day)
day <- str_remove(day, "th")
day <- str_remove(day, "rd")
day <- str_remove(day, "st")

months <- unlist(months)
months <- replace(months, c(1, 2), "12")
months <- replace(months, c(3, 4, 5), "1")
months <- replace(months, c(6, 7), "2")
months <- replace(months, c(8, 9, 10), "3")

planting4$Month <- months
planting4$Day <- day
planting4$Year <- year

planting4$Total_Date <- paste(year, months, day, sep=".")
labeling <- paste(months, day, sep=".")

planting4 = planting4 %>% rename("genesis"= "nd genesis")
planting4 = planting4 %>% rename("ndsu"= "ndsu-2nd32529")

colors<- c("Conlon"="red", "Robust"="orange", "Rasmusson"="yellow", "ND Genesis"="green", "Opera"="blue", "Copeland"="purple", "Ndsu-2nd32529"="white", "Genie"="pink", "Odyssey"="brown", "Pinnacle"="tan")

ggplot(planting4, aes(x=Total_Date))+
  geom_line(aes(y = conlon, group=1, color="Conlon")) + 
  geom_line(aes(y=robust, group=1, color="Robust"))+
  geom_line(aes(y=rasmusson, group=1, color="Rasmusson"))+
  geom_line(aes(y=genesis, group=1, color="ND Genesis"))+
  geom_line(aes(y=opera, group=1, color="Opera"))+
  geom_line(aes(y=copeland, group=1, color="Copeland"))+
  geom_line(aes(y=ndsu, group=1, color="Ndsu-2nd32529"))+
  geom_line(aes(y=genie, group=1, color="Genie"))+
  geom_line(aes(y=odyssey, group=1, color="Odyssey"))+
  geom_line(aes(y=pinnacle, group=1, color="Pinnacle"))+
  scale_x_discrete(labels=labeling) + 
  ggtitle("Fourth Planting Date w/ ten varieties (Height)") +
  xlab("Month-Day (2021-2022)") +
  ylab("Average Height (cm)")+
  theme_dark()+
  theme(axis.text=element_text(size=8))+
  scale_color_manual(values=colors)+
  labs(color="Color")

planting4 = read_excel("planting4feekes.xlsx")
planting4 = tibble(planting4)

months <- strsplit(planting4$Date, ' ') %>% lapply('[[', 1)
day <- strsplit(planting4$Date, ' ') %>% lapply('[[', 2)
year <- strsplit(planting4$Date, ' ') %>% lapply('[[', 3)

year <- str_remove(year, "'")

day <- unlist(day)
day <- str_remove(day, "th")
day <- str_remove(day, "rd")
day <- str_remove(day, "st")

months <- unlist(months)
months <- replace(months, c(1, 2), "12")
months <- replace(months, c(3, 4, 5), "1")
months <- replace(months, c(6, 7), "2")
months <- replace(months, c(8, 9, 10), "3")

planting4$Month <- months
planting4$Day <- day
planting4$Year <- year

planting4$Total_Date <- paste(year, months, day, sep=".")
labeling <- paste(months, day, sep=".")

planting4 = planting4 %>% rename("genesis"= "nd genesis")
planting4 = planting4 %>% rename("ndsu"= "ndsu-2nd32529")

colors<- c("Conlon"="red", "Robust"="orange", "Rasmusson"="yellow", "ND Genesis"="green", "Opera"="blue", "Copeland"="purple", "Ndsu-2nd32529"="white", "Genie"="pink", "Odyssey"="brown", "Pinnacle"="tan")

ggplot(planting4, aes(x=Total_Date))+
  geom_line(aes(y = conlon, group=1, color="Conlon")) + 
  geom_line(aes(y=robust, group=1, color="Robust"))+
  geom_line(aes(y=rasmusson, group=1, color="Rasmusson"))+
  geom_line(aes(y=genesis, group=1, color="ND Genesis"))+
  geom_line(aes(y=opera, group=1, color="Opera"))+
  geom_line(aes(y=copeland, group=1, color="Copeland"))+
  geom_line(aes(y=ndsu, group=1, color="Ndsu-2nd32529"))+
  geom_line(aes(y=genie, group=1, color="Genie"))+
  geom_line(aes(y=odyssey, group=1, color="Odyssey"))+
  geom_line(aes(y=pinnacle, group=1, color="Pinnacle"))+
  scale_x_discrete(labels=labeling) + 
  ggtitle("Fourth Planting Date w/ ten varieties (Feekes Scale)") +
  xlab("Month-Day (2021-2022)") +
  ylab("Average Feekes Scale Rating")+
  theme_dark()+
  theme(axis.text=element_text(size=8))+
  scale_color_manual(values=colors)+
  labs(color="Color")

#Plot 5
planting5 = read_excel("planting5.xlsx")
planting5 = tibble(planting5)

months <- strsplit(planting5$Date, ' ') %>% lapply('[[', 1)
day <- strsplit(planting5$Date, ' ') %>% lapply('[[', 2)
year <- strsplit(planting5$Date, ' ') %>% lapply('[[', 3)

year <- str_remove(year, "'")

day <- unlist(day)
day <- str_remove(day, "th")
day <- str_remove(day, "rd")
day <- str_remove(day, "st")

months <- unlist(months)
months <- replace(months, c(1), "12")
months <- replace(months, c(2, 3, 4), "1")
months <- replace(months, c(5, 6), "2")
months <- replace(months, c(7, 8, 9), "3")

planting5$Month <- months
planting5$Day <- day
planting5$Year <- year

planting5$Total_Date <- paste(year, months, day, sep=".")
labeling <- paste(months, day, sep=".")

planting5 = planting5 %>% rename("genesis"= "nd genesis")
planting5 = planting5 %>% rename("ndsu"= "ndsu-2nd32529")

colors<- c("Conlon"="red", "Robust"="orange", "Rasmusson"="yellow", "ND Genesis"="green", "Opera"="blue", "Copeland"="purple", "Ndsu-2nd32529"="white", "Genie"="pink", "Odyssey"="brown", "Pinnacle"="tan")

ggplot(planting5, aes(x=Total_Date))+
  geom_line(aes(y = conlon, group=1, color="Conlon")) + 
  geom_line(aes(y=robust, group=1, color="Robust"))+
  geom_line(aes(y=rasmusson, group=1, color="Rasmusson"))+
  geom_line(aes(y=genesis, group=1, color="ND Genesis"))+
  geom_line(aes(y=opera, group=1, color="Opera"))+
  geom_line(aes(y=copeland, group=1, color="Copeland"))+
  geom_line(aes(y=ndsu, group=1, color="Ndsu-2nd32529"))+
  geom_line(aes(y=genie, group=1, color="Genie"))+
  geom_line(aes(y=odyssey, group=1, color="Odyssey"))+
  geom_line(aes(y=pinnacle, group=1, color="Pinnacle"))+
  scale_x_discrete(labels=labeling) + 
  ggtitle("Fifth Planting Date w/ ten varieties (Height)") +
  xlab("Month-Day (2021-2022)") +
  ylab("Average Height (cm)")+
  theme_dark()+
  theme(axis.text=element_text(size=8))+
  scale_color_manual(values=colors)+
  labs(color="Color")

planting5 = read_excel("planting5feekes.xlsx")
planting5 = tibble(planting5)

months <- strsplit(planting5$Date, ' ') %>% lapply('[[', 1)
day <- strsplit(planting5$Date, ' ') %>% lapply('[[', 2)
year <- strsplit(planting5$Date, ' ') %>% lapply('[[', 3)

year <- str_remove(year, "'")

day <- unlist(day)
day <- str_remove(day, "th")
day <- str_remove(day, "rd")
day <- str_remove(day, "st")

months <- unlist(months)
months <- replace(months, c(1), "12")
months <- replace(months, c(2, 3, 4), "1")
months <- replace(months, c(5, 6), "2")
months <- replace(months, c(7, 8, 9), "3")

planting5$Month <- months
planting5$Day <- day
planting5$Year <- year

planting5$Total_Date <- paste(year, months, day, sep=".")
labeling <- paste(months, day, sep=".")

planting5 = planting5 %>% rename("genesis"= "nd genesis")
planting5 = planting5 %>% rename("ndsu"= "ndsu-2nd32529")

colors<- c("Conlon"="red", "Robust"="orange", "Rasmusson"="yellow", "ND Genesis"="green", "Opera"="blue", "Copeland"="purple", "Ndsu-2nd32529"="white", "Genie"="pink", "Odyssey"="brown", "Pinnacle"="tan")

ggplot(planting5, aes(x=Total_Date))+
  geom_line(aes(y = conlon, group=1, color="Conlon")) + 
  geom_line(aes(y=robust, group=1, color="Robust"))+
  geom_line(aes(y=rasmusson, group=1, color="Rasmusson"))+
  geom_line(aes(y=genesis, group=1, color="ND Genesis"))+
  geom_line(aes(y=opera, group=1, color="Opera"))+
  geom_line(aes(y=copeland, group=1, color="Copeland"))+
  geom_line(aes(y=ndsu, group=1, color="Ndsu-2nd32529"))+
  geom_line(aes(y=genie, group=1, color="Genie"))+
  geom_line(aes(y=odyssey, group=1, color="Odyssey"))+
  geom_line(aes(y=pinnacle, group=1, color="Pinnacle"))+
  scale_x_discrete(labels=labeling) + 
  ggtitle("Fifth Planting Date w/ ten varieties (Feekes Scale)") +
  xlab("Month-Day (2021-2022)") +
  ylab("Average Feekes Scale Rating")+
  theme_dark()+
  theme(axis.text=element_text(size=8))+
  scale_color_manual(values=colors)+
  labs(color="Color")




#analysis code
height1 = read_excel("Mean_Height_aov.xlsx")
height1 = tibble(height1)

height.mod.1 = aov(Mean_Height ~ Variety*Planting, data = height1)
summary(height.mod.1)

height.mod.2 = aov(Mean_Feekes ~ Variety*Planting, data = height1)
summary(height.mod.2)


planting1 = read_excel("Planting1_aov.xlsx")
planting1 = tibble(planting1)

model3 <- aov(Height ~ Variety * Date, data = planting1)
summary(model3)

model4 <- aov(Feekes ~ Variety * Date, data = planting1)
summary(model4)

cor(planting1$Days_Passed, planting1$Height)
